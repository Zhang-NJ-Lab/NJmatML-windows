from PyQt5 import QtCore, QtGui, QtWidgets, Qt
from PyQt5.QtWidgets import QFileDialog, QMessageBox
from PyQt5.QtGui import QImage, QPixmap
from PyQt5.QtCore import QTimer
from untitled1 import Ui_MainWindow
import dialog_five_one,dialog_six_one_two,dialog_six_two_two,dialog_six_eleven_two

from NJmatML import dataML
import argparse
import warnings
#import rdkit
warnings.filterwarnings("ignore")

import os
import shutil

class mywindow(QtWidgets.QMainWindow, Ui_MainWindow):
    def __init__(self):
        super(mywindow, self).__init__()
        self.setupUi(self)
        self.setWindowTitle("NJmatML")
        self.setWindowIcon(QtGui.QIcon("test.ico"))
        self.parser = argparse.ArgumentParser()
        self.parser.add_argument("--origin_path_1", type=str,default="D:/project_zl/2DEformationCleaned.csv",help="1默认文件路径")
        self.parser.add_argument("--origin_path_2", type=str, default="D:/project_zl/x_New.csv",help="2默认文件路径")
        self.parser.add_argument("--origin_path_3", type=str, default="D:/project_zl/Featurize_formula_exps.csv",
                                help="3默认文件路径")
        self.parser.add_argument("--origin_path_4", type=str, default="D:/project_zl/Inorganic_formula.csv",
                                 help="4默认文件路径")
        self.parser.add_argument("--save_path", type=str, default="D:/project_zl/new_generate",help="保存在此文件夹")
        self.parser.add_argument("--if_open", default=False, help="是否打开生成的文件(csv,png,txt,tif),true是打开")    # Todo 改
        self.parser.add_argument("--if_control", default=False, help="是否控制按键逻辑(1,2,3...),false是控制")           # Todo 改

        self.opt = self.parser.parse_args()                                # 封装参数

        self.num_1=0
        self.num_2 = 0
        self.num_3 = 0
        self.num_4 = 0
        self.num_5 = 0
        self.num_6 = 0
        self.num_7 = 0

        # 触发
        self.action_2.triggered.connect(self.enter_one)
        self.action_5.triggered.connect(self.enter_two)
        self.action_smiles.triggered.connect(self.enter_three)
        self.action_6.triggered.connect(self.enter_four)
        self.action.triggered.connect(self.save_bag)


        # 1
        self.action_7.triggered.connect(self.one)

        # 2
        self.action_heatmap.triggered.connect(self.two)

        # 3
        self.actionrfe.triggered.connect(self.three)

        # 4
        self.action_rfe.triggered.connect(self.four_one)
        self.action_rfe_pairplot.triggered.connect(self.four_two)

        # 5
        self.action_3.triggered.connect(self.show_dialog_five_one)
        self.action_4.triggered.connect(self.show_dialog_five_two)

        # 6
        self.action6_1_1xgboost.triggered.connect(self.six_one_one)
        self.action6_1_2xgboost.triggered.connect(self.show_dialog_six_one_two)
        self.action6_1_3xgboostRandomSearchCV.triggered.connect(self.six_one_three)
        self.action6_1_4xgboost_SearchCV.triggered.connect(self.six_one_four)
        self.action6_2_1Random_forest.triggered.connect(self.six_two_one)
        self.action6_2_2Random_forest.triggered.connect(self.show_dialog_six_two_two)
        self.action6_2_3Random_forest_RandomSearchCV.triggered.connect(self.six_two_three)
        self.action6_3_1Bagging.triggered.connect(self.six_three_one)
        self.action6_4_1AdaBoost.triggered.connect(self.six_four_one)
        self.action6_5_1GradientBoosting.triggered.connect(self.six_five_one)
        self.action6_6_1ExtraTree.triggered.connect(self.six_six_one)
        self.action6_7_1svm.triggered.connect(self.six_seven_one)
        self.action6_8_1DecisionTree.triggered.connect(self.six_eight_one)
        self.action6_9_1LinearRegression.triggered.connect(self.six_nine_one)
        self.action6_10_1Ridge.triggered.connect(self.six_ten_one)
        self.action6_11_1MLP.triggered.connect(self.six_eleven_one)
        self.action6_11_2MLP_modify.triggered.connect(self.show_dialog_six_eleven_two)

        # 7
        self.action_8.triggered.connect(self.seven_one)
        self.action_xgboost_modify.triggered.connect(self.show_dialog_seven_two)
        self.action7_3_rnd_search_cv_xgboost.triggered.connect(self.seven_three)

        # 8
        self.action8_1_1pydel.triggered.connect(self.eight_one_one)
        self.action8_1_2_rdkit.triggered.connect(self.eight_one_two)
        self.actionmatminer.triggered.connect(self.eight_two)

        # 9
        self.action9_1.triggered.connect(self.nine_one)
        self.action9_2.triggered.connect(self.nine_two)
        self.action9_3_tSR.triggered.connect(self.nine_three)



        self.enter_one_state=self.opt.if_control                      # 由于本电脑有默认导入文件路径，所以可由if_control控制，方便测试
        self.enter_two_state = self.opt.if_control
        self.enter_three_state =self.opt.if_control
        self.enter_four_state = self.opt.if_control

        self.dialog_state=False                                       # 先输入后确定
        self.one_state=self.opt.if_control                            # 控制按钮触发前后顺序
        self.two_state = self.opt.if_control
        self.three_state = self.opt.if_control
        self.four_state = self.opt.if_control
        self.five_state = self.opt.if_control
        self.six_state = self.opt.if_control
        self.seven_state = self.opt.if_control
        self.nine_state = self.opt.if_control

    # 状态重置
    def clear_state(self):
        self.one_state = self.opt.if_control
        self.two_state = self.opt.if_control
        self.three_state = self.opt.if_control
        self.four_state = self.opt.if_control
        self.five_state = self.opt.if_control
        self.six_state = self.opt.if_control
        self.seven_state = self.opt.if_control
        self.nine_state = self.opt.if_control

    # 载入路径
    def enter_one(self):

            directory_temp, filetype = QFileDialog.getOpenFileNames(self, "选取文件")
            if len(directory_temp)>0:
                str_root = str(directory_temp)
                f_csv = str_root.rfind('.csv')
                if f_csv!=-1:                                                 # 判断是不是.csv
                    self.opt.origin_path_1 = str((str_root.replace("\\",'/'))[2:-2])
                    self.enter_one_state = True
                    QMessageBox.information(self, '提示', '完成', QMessageBox.Ok | QMessageBox.Close,
                                            QMessageBox.Close)
                else:
                    QMessageBox.information(self, '提示', '不是.csv文件,请重新输入!', QMessageBox.Ok | QMessageBox.Close,
                                            QMessageBox.Close)
            else:
                QMessageBox.information(self, '提示', '请输入一个文件!', QMessageBox.Ok | QMessageBox.Close,
                                        QMessageBox.Close)

    def enter_two(self):

            directory_temp, filetype = QFileDialog.getOpenFileNames(self, "选取文件")
            if len(directory_temp) > 0:
                str_root = str(directory_temp)
                f_csv = str_root.rfind('.csv')
                if f_csv != -1:                                                # 判断是不是.csv
                    self.opt.origin_path_2=str((str_root.replace("\\", '/'))[2:-2])
                    self.enter_two_state = True
                    QMessageBox.information(self, '提示', '完成', QMessageBox.Ok | QMessageBox.Close,
                                                QMessageBox.Close)
                else:
                    QMessageBox.information(self, '提示', '不是.csv文件,请重新输入!', QMessageBox.Ok | QMessageBox.Close,
                                            QMessageBox.Close)
            else:
                QMessageBox.information(self, '提示', '请输入一个文件!', QMessageBox.Ok | QMessageBox.Close,
                                        QMessageBox.Close)

    def enter_three(self):

            directory_temp, filetype = QFileDialog.getOpenFileNames(self, "选取文件")
            if len(directory_temp) > 0:
                str_root = str(directory_temp)
                f_csv = str_root.rfind('.csv')
                if f_csv != -1:                                                    # 判断是不是.csv
                    self.opt.origin_path_3=str((str_root.replace("\\", '/'))[2:-2])
                    self.enter_three_state = True
                    QMessageBox.information(self, '提示', '完成', QMessageBox.Ok | QMessageBox.Close,
                                            QMessageBox.Close)
                else:
                    QMessageBox.information(self, '提示', '不是.csv文件,请重新输入!', QMessageBox.Ok | QMessageBox.Close,
                                            QMessageBox.Close)
            else:
                QMessageBox.information(self, '提示', '请输入一个文件!', QMessageBox.Ok | QMessageBox.Close,
                                        QMessageBox.Close)

    def enter_four(self):

            directory_temp, filetype = QFileDialog.getOpenFileNames(self, "选取文件")
            if len(directory_temp) > 0:
                str_root = str(directory_temp)
                f_csv = str_root.rfind('.csv')
                if f_csv != -1:                                           # 判断是不是.csv
                    self.opt.origin_path_4= str((str_root.replace("\\", '/'))[2:-2])
                    self.enter_four_state = True
                    QMessageBox.information(self, '提示', '完成', QMessageBox.Ok | QMessageBox.Close,
                                            QMessageBox.Close)
                else:
                    QMessageBox.information(self, '提示', '不是.csv文件,请重新输入!', QMessageBox.Ok | QMessageBox.Close,
                                            QMessageBox.Close)
            else:
                QMessageBox.information(self, '提示', '请输入一个文件!', QMessageBox.Ok | QMessageBox.Close,
                                        QMessageBox.Close)

    def save_bag(self):
        self.opt.save_path = QFileDialog.getExistingDirectory(self,"选取文件夹")  # 起始路径
        QMessageBox.information(self, '提示', '完成', QMessageBox.Ok | QMessageBox.Close,
                                QMessageBox.Close)








    #  菜单下拉栏
    # 1
    def one(self):
        try:
            if self.enter_one_state == True:
                self.clear_state()
                self.one_state=True
                path=self.opt.save_path+"/one"
                if os.path.exists(path):                                       # 重做得删文件夹
                    shutil.rmtree(path)
                os.makedirs(path)
                dataML.file_name(self.opt.origin_path_1,path)                  #打开csv并存到data中
                dataML.hist(path)  #画所有列分布的柱状图，例如potential 在0.3 V最多
                QMessageBox.information(self, '提示', '完成', QMessageBox.Ok | QMessageBox.Close,
                                        QMessageBox.Close)

                if self.opt.if_open==True:
                    str1= (path+'/hist_allFeatures.png').replace("/", "\\")
                    os.startfile(str1)
                    str2 = (path + "/data.csv").replace("/", "\\")
                    os.startfile(str2)
            else:
                QMessageBox.information(self, '提示', '未导入训练测试集', QMessageBox.Ok | QMessageBox.Close,
                                        QMessageBox.Close)
        except Exception as e:
            print(e)

    # 2                                           # 1 2
    def two(self):
        if self.one_state==True:
            self.two_state=True
            path = self.opt.save_path + "/two"
            if os.path.exists(path):
                shutil.rmtree(path)
            os.makedirs(path)
            dataML.heatmap_before(path)  # 画封装函数特征选择之前heatmap热图
            QMessageBox.information(self, '提示', '完成', QMessageBox.Ok | QMessageBox.Close,
                                    QMessageBox.Close)
            if self.opt.if_open == True:
                str1 = (path+'/heatmap-before.png').replace("/", "\\")
                os.startfile(str1)
        else:
            QMessageBox.information(self, '提示', '第一步未运行', QMessageBox.Ok | QMessageBox.Close,
                                    QMessageBox.Close)

    # 3                                           # 1 3
    def three(self):
        # 后面四个数字的作用依次是 初始值 最小值 最大值 步幅
        if self.one_state==True:
            self.three_state=True

            path = self.opt.save_path + "/three"
            if os.path.exists(path):
                shutil.rmtree(path)
            os.makedirs(path)
            value, ok = QtWidgets.QInputDialog.getInt(self, "输入整数", "请输入希望最后剩余的特征数目:", 37, -10000, 10000, 2)
            dataML.feature_rfe_select1(value,path)
            QMessageBox.information(self, '提示', '完成', QMessageBox.Ok | QMessageBox.Close,
                                    QMessageBox.Close)

            if self.opt.if_open == True:
                str1 = (path + "/data.txt").replace("/", "\\")
                os.startfile(str1)
                str2 = (path + "/target.csv").replace("/", "\\")
                os.startfile(str2)
                str3 = (path + "/data_rfe.csv").replace("/", "\\")
                os.startfile(str3)
        else:
            QMessageBox.information(self, '提示', '第一步未运行', QMessageBox.Ok | QMessageBox.Close,
                                    QMessageBox.Close)

    # 4                                           # 1 3 4
    def four_one(self):
        if self.one_state == True:
            if self.three_state == True:
                self.four_state = True
                path = self.opt.save_path + "/four/one"
                if os.path.exists(path):
                    shutil.rmtree(path)
                os.makedirs(path)
                dataML.heatmap_afterRFE(path)
                QMessageBox.information(self, '提示', '完成', QMessageBox.Ok | QMessageBox.Close,
                                        QMessageBox.Close)
                if self.opt.if_open == True:
                    str1 = (path+'/heatmap-afterRFE.csv').replace("/", "\\")
                    os.startfile(str1)
                    str2 = (path + '/heatmap-afterRFE.png').replace("/", "\\")
                    os.startfile(str2)
            else:
                QMessageBox.information(self, '提示', '第三步未运行', QMessageBox.Ok | QMessageBox.Close,
                                        QMessageBox.Close)
        else:
            QMessageBox.information(self, '提示', '第一步未运行', QMessageBox.Ok | QMessageBox.Close,
                                    QMessageBox.Close)

    def four_two(self):
        if self.one_state == True:
            if self.three_state == True:
                self.four_state = True
                path = self.opt.save_path + "/four/two"
                if os.path.exists(path):
                    shutil.rmtree(path)
                os.makedirs(path)
                dataML.pairplot_afterRFE(path)
                QMessageBox.information(self, '提示', '完成', QMessageBox.Ok | QMessageBox.Close,
                                        QMessageBox.Close)
                if self.opt.if_open == True:
                    str1 = (path+'/sns-pairplot-remain.png').replace("/", "\\")
                    os.startfile(str1)
            else:
                QMessageBox.information(self, '提示', '第三步未运行', QMessageBox.Ok | QMessageBox.Close,
                                        QMessageBox.Close)
        else:
            QMessageBox.information(self, '提示', '第一步未运行', QMessageBox.Ok | QMessageBox.Close,
                                    QMessageBox.Close)

    # 5                                           # 1 2 3 5
    def five_one(self):
        if self.dialog_state==True:                                      # 一定先输入再确定
            path = self.opt.save_path + "/five/one"
            if os.path.exists(path):
                shutil.rmtree(path)
            os.makedirs(path)
            self.di.close()
            print(self.num_1,self.num_2,self.num_3,self.num_4)
            dataML.FeatureImportance_before(int(self.num_1),int(self.num_2),int(self.num_3),int(self.num_4),path)  # 输入一定要int
            self.dialog_state = False                                   # 用完就初始化，作为全局得共用
            QMessageBox.information(self, '提示', '完成', QMessageBox.Ok | QMessageBox.Close,
                                    QMessageBox.Close)
            if self.opt.if_open == True:
                str1 = (path+'/FeatureImportance_before.png').replace("/", "\\")
                os.startfile(str1)
        else:
            QMessageBox.information(self, '提示', '未按输入', QMessageBox.Ok | QMessageBox.Close,
                                    QMessageBox.Close)
    def show_dialog_five_one(self):
        def give(a,b,c,d):
            self.num_1=a
            self.num_2 = b
            self.num_3 = c
            self.num_4 = d
            self.dialog_state = True

        if self.one_state == True:
            if self.two_state == True:
                if self.three_state == True:
                    self.five_state = True
                    self.di = QtWidgets.QDialog()
                    d = dialog_five_one.Ui_Dialog()
                    d.setupUi(self.di)
                    self.di.show()

                    d.pushButton.clicked.connect(lambda :give(d.lineEdit.text(),d.lineEdit_2.text(),d.lineEdit_3.text(),d.lineEdit_4.text()))

                    d.pushButton_2.clicked.connect(self.five_one)
                else:
                    QMessageBox.information(self, '提示', '第三步未运行', QMessageBox.Ok | QMessageBox.Close,
                                            QMessageBox.Close)
            else:
                QMessageBox.information(self, '提示', '第二步未运行', QMessageBox.Ok | QMessageBox.Close,
                                        QMessageBox.Close)
        else:
            QMessageBox.information(self, '提示', '第一步未运行', QMessageBox.Ok | QMessageBox.Close,
                                    QMessageBox.Close)


    def five_two(self):
        if self.dialog_state == True:
            path = self.opt.save_path + "/five/two"
            if os.path.exists(path):
                shutil.rmtree(path)
            os.makedirs(path)
            self.di.close()
            dataML.FeatureImportance_afterRFE(int(self.num_1),int(self.num_2),int(self.num_3),int(self.num_4),path)
            self.dialog_state = False
            QMessageBox.information(self, '提示', '完成', QMessageBox.Ok | QMessageBox.Close,
                                    QMessageBox.Close)
            if self.opt.if_open == True:
                str1 = (path+'/FeatureImportance_after.png').replace("/", "\\")
                os.startfile(str1)
        else:
            QMessageBox.information(self, '提示', '未按输入', QMessageBox.Ok | QMessageBox.Close,
                                    QMessageBox.Close)
    def show_dialog_five_two(self):
        def give(a,b,c,d):
            self.num_1=a
            self.num_2 = b
            self.num_3 = c
            self.num_4 = d
            self.dialog_state = True

        if self.one_state == True:
            if self.two_state == True:
                if self.three_state == True:
                    self.five_state = True
                    self.di = QtWidgets.QDialog()
                    d = dialog_five_one.Ui_Dialog()
                    d.setupUi(self.di)
                    self.di.show()

                    d.pushButton.clicked.connect(lambda :give(d.lineEdit.text(),d.lineEdit_2.text(),d.lineEdit_3.text(),d.lineEdit_4.text()))
                    d.pushButton_2.clicked.connect(self.five_two)
                else:
                    QMessageBox.information(self, '提示', '第三步未运行', QMessageBox.Ok | QMessageBox.Close,
                                            QMessageBox.Close)
            else:
                QMessageBox.information(self, '提示', '第二步未运行', QMessageBox.Ok | QMessageBox.Close,
                                        QMessageBox.Close)
        else:
            QMessageBox.information(self, '提示', '第一步未运行', QMessageBox.Ok | QMessageBox.Close,
                                    QMessageBox.Close)

    # 6                                           # 1 3 6
    def six_one_one(self):
        try:
            if self.one_state == True:
                if self.three_state == True:
                    self.six_state = True
                    path = self.opt.save_path + "/six/one/one"
                    if os.path.exists(path):
                        shutil.rmtree(path)
                    os.makedirs(path)

                    dataML.xgboost_default(path)
                    QMessageBox.information(self, '提示', '完成', QMessageBox.Ok | QMessageBox.Close,
                                            QMessageBox.Close)
                    if self.opt.if_open == True:
                        str1 = (path+'/xgboost-default.png').replace("/", "\\")
                        os.startfile(str1)
                        str2 = (path+'/xgboost-default-10-fold-crossvalidation.png').replace("/", "\\")
                        os.startfile(str2)
                        str3 = (path+'/xgboost-default-train.png').replace("/", "\\")
                        os.startfile(str3)
                else:
                    QMessageBox.information(self, '提示', '第三步未运行', QMessageBox.Ok | QMessageBox.Close,
                                            QMessageBox.Close)
            else:
                QMessageBox.information(self, '提示', '第一步未运行', QMessageBox.Ok | QMessageBox.Close,
                                        QMessageBox.Close)
        except Exception as e:
            print(e)

    def six_one_two(self):
        if self.dialog_state == True:
            path = self.opt.save_path + "/six/one/two"
            if os.path.exists(path):
                shutil.rmtree(path)
            os.makedirs(path)
            self.di.close()

            dataML.xgboost_modify(int(self.num_1),int(self.num_2),self.num_3,self.num_4
                                  ,self.num_5,self.num_6,self.num_7,path)  # 三个图，第一个图测试集拟合，第二个图交叉验证，第三个图训练集的拟合（没什么用）
            self.dialog_state = False
            # (n_estimators=1000, max_depth=200, eta=0.2, gamma=0, subsample=0.9, colsample_bytree=0.8, learning_rate=0.2)
            QMessageBox.information(self, '提示', '完成', QMessageBox.Ok | QMessageBox.Close,
                                    QMessageBox.Close)
            if self.opt.if_open == True:
                str1 = (path+'/xgboost-modify.png').replace("/", "\\")
                os.startfile(str1)
                str2 = (path+'/xgboost_modify-10-fold-crossvalidation.png').replace("/", "\\")
                os.startfile(str2)
                str3 = (path+'/xgboost-modify-train-default.png').replace("/", "\\")
                os.startfile(str3)
        else:
            QMessageBox.information(self, '提示', '未按输入', QMessageBox.Ok | QMessageBox.Close,
                                    QMessageBox.Close)
    def show_dialog_six_one_two(self):
        def give(a,b,c,d,e,f,g):
            self.num_1=a
            self.num_2 = b
            self.num_3 = c
            self.num_4 = d
            self.num_5 = e
            self.num_6 = f
            self.num_7 = g
            self.dialog_state = True

        if self.one_state == True:
            if self.three_state == True:
                self.six_state = True
                self.di = QtWidgets.QDialog()
                d = dialog_six_one_two.Ui_Dialog()
                d.setupUi(self.di)
                self.di.show()

                d.pushButton.clicked.connect(lambda :give(d.lineEdit.text(),d.lineEdit_2.text(),d.lineEdit_3.text(),d.lineEdit_4.text()
                                                          ,d.lineEdit_5.text(),d.lineEdit_6.text(),d.lineEdit_7.text()))
                d.pushButton_2.clicked.connect(self.six_one_two)
            else:
                QMessageBox.information(self, '提示', '第三步未运行', QMessageBox.Ok | QMessageBox.Close,
                                        QMessageBox.Close)
        else:
            QMessageBox.information(self, '提示', '第一步未运行', QMessageBox.Ok | QMessageBox.Close,
                                    QMessageBox.Close)

    def six_one_three(self):
        if self.one_state == True:
            if self.three_state == True:
                self.six_state = True
                path = self.opt.save_path + "/six/one/three"
                if os.path.exists(path):
                    shutil.rmtree(path)
                os.makedirs(path)

                dataML.xgboost_RandomSearchCV(path)
                QMessageBox.information(self, '提示', '完成', QMessageBox.Ok | QMessageBox.Close,
                                        QMessageBox.Close)
                if self.opt.if_open == True:
                    str1 = (path+'/xgboost-RandomizedSearchCV.png').replace("/", "\\")
                    os.startfile(str1)
                    str2 = (path+'/Xgboost_rnd_search_cv-10-fold-crossvalidation.png').replace("/", "\\")
                    os.startfile(str2)
                    str3 = (path+'/xgboost-train-randomSearch.png').replace("/", "\\")
                    os.startfile(str3)
            else:
                QMessageBox.information(self, '提示', '第三步未运行', QMessageBox.Ok | QMessageBox.Close,
                                            QMessageBox.Close)
        else:
            QMessageBox.information(self, '提示', '第一步未运行', QMessageBox.Ok | QMessageBox.Close,
                                        QMessageBox.Close)

    def six_one_four(self):
        if self.one_state == True:
            if self.three_state == True:
                self.six_state = True
                path = self.opt.save_path + "/six/one/four"
                if os.path.exists(path):
                    shutil.rmtree(path)
                os.makedirs(path)

                dataML.xgboost_GridSearchCV(path)
                QMessageBox.information(self, '提示', '完成', QMessageBox.Ok | QMessageBox.Close,
                                        QMessageBox.Close)
                if self.opt.if_open == True:
                    str1 = (path+'/xgboost-GridSearchCV.png').replace("/", "\\")
                    os.startfile(str1)
                    str2 = (path+'/grid_search_cv-10-fold-crossvalidation.png').replace("/", "\\")
                    os.startfile(str2)
                    str3 = (path+'/Xgboost-grid_search_train.png').replace("/", "\\")
                    os.startfile(str3)
            else:
                QMessageBox.information(self, '提示', '第三步未运行', QMessageBox.Ok | QMessageBox.Close,
                                            QMessageBox.Close)
        else:
            QMessageBox.information(self, '提示', '第一步未运行', QMessageBox.Ok | QMessageBox.Close,
                                        QMessageBox.Close)

    def six_two_one(self):
        if self.one_state == True:
            if self.three_state == True:
                self.six_state = True
                path = self.opt.save_path + "/six/two/one"
                if os.path.exists(path):
                    shutil.rmtree(path)
                os.makedirs(path)

                dataML.RandomForest_default(path)
                QMessageBox.information(self, '提示', '完成', QMessageBox.Ok | QMessageBox.Close,
                                        QMessageBox.Close)
                if self.opt.if_open == True:
                    str1 = (path+'/randomForest-default.png').replace("/", "\\")
                    os.startfile(str1)
                    str2 = (path+'/randomForest-default-10-fold-crossvalidation.png').replace("/", "\\")
                    os.startfile(str2)
                    str3 = (path+'/randomForest-default-train.png').replace("/", "\\")
                    os.startfile(str3)
            else:
                QMessageBox.information(self, '提示', '第三步未运行', QMessageBox.Ok | QMessageBox.Close,
                                            QMessageBox.Close)
        else:
            QMessageBox.information(self, '提示', '第一步未运行', QMessageBox.Ok | QMessageBox.Close,
                                        QMessageBox.Close)

    def six_two_two(self):
        if self.dialog_state == True:
            path = self.opt.save_path + "/six/two/two"
            if os.path.exists(path):
                shutil.rmtree(path)
            os.makedirs(path)
            self.di.close()
            try:
                dataML.RandomForest_modify(int(self.num_1),float(self.num_2),int(self.num_3),int(self.num_4)
                                  ,int(self.num_5),path)

            except Exception as e:
                print(e)
            self.dialog_state = False
            QMessageBox.information(self, '提示', '完成', QMessageBox.Ok | QMessageBox.Close,
                                    QMessageBox.Close)
            if self.opt.if_open == True:
                str1 = (path+'/RandomForest-modify.png').replace("/", "\\")
                os.startfile(str1)
                str2 = (path+'/RandomForest_modify-10-fold-crossvalidation.png').replace("/", "\\")
                os.startfile(str2)
                str3 = (path+'/RandomForest-modify-train.png').replace("/", "\\")
                os.startfile(str3)
        else:
            QMessageBox.information(self, '提示', '未按输入', QMessageBox.Ok | QMessageBox.Close,
                                    QMessageBox.Close)
    def show_dialog_six_two_two(self):
        def give(a,b,c,d,e):
            self.num_1=a
            self.num_2 = b
            self.num_3 = c
            self.num_4 = d
            self.num_5 = e
            self.dialog_state = True

        if self.one_state == True:
            if self.three_state == True:
                self.six_state = True
                self.di = QtWidgets.QDialog()
                d = dialog_six_two_two.Ui_Dialog()
                d.setupUi(self.di)
                self.di.show()

                d.pushButton.clicked.connect(lambda :give(d.lineEdit_2.text(),d.lineEdit.text(),d.lineEdit_3.text(),d.lineEdit_4.text()
                                                          ,d.lineEdit_5.text()))
                d.pushButton_2.clicked.connect(self.six_two_two)
            else:
                QMessageBox.information(self, '提示', '第三步未运行', QMessageBox.Ok | QMessageBox.Close,
                                            QMessageBox.Close)
        else:
            QMessageBox.information(self, '提示', '第一步未运行', QMessageBox.Ok | QMessageBox.Close,
                                        QMessageBox.Close)

    def six_two_three(self):
        if self.one_state == True:
            if self.three_state == True:
                self.six_state = True
                path = self.opt.save_path + "/six/two/three"
                if os.path.exists(path):
                    shutil.rmtree(path)
                os.makedirs(path)

                dataML.RandomForest_RandomSearchCV(path)
                QMessageBox.information(self, '提示', '完成', QMessageBox.Ok | QMessageBox.Close,
                                        QMessageBox.Close)
                if self.opt.if_open == True:
                    str1 = (path+'/RandomForest-RandomizedSearchCV.png').replace("/", "\\")
                    os.startfile(str1)
                    str2 = (path+'/RandomForest_rnd_search_cv-10-fold-crossvalidation.png').replace("/", "\\")
                    os.startfile(str2)
                    str3 = (path+'/RandomForest-train-randomSearchCV.png').replace("/", "\\")
                    os.startfile(str3)
            else:
                QMessageBox.information(self, '提示', '第三步未运行', QMessageBox.Ok | QMessageBox.Close,
                                            QMessageBox.Close)
        else:
            QMessageBox.information(self, '提示', '第一步未运行', QMessageBox.Ok | QMessageBox.Close,
                                        QMessageBox.Close)

    def six_three_one(self):
        if self.one_state == True:
            if self.three_state == True:
                self.six_state = True
                path = self.opt.save_path + "/six/three/one"
                if os.path.exists(path):
                    shutil.rmtree(path)
                os.makedirs(path)

                dataML.Bagging_default(path)
                QMessageBox.information(self, '提示', '完成', QMessageBox.Ok | QMessageBox.Close,
                                        QMessageBox.Close)
                if self.opt.if_open == True:
                    str1 = (path+'/Bagging-default.png').replace("/", "\\")
                    os.startfile(str1)
                    str2 = (path+'/Bagging-default-10-fold-crossvalidation.png').replace("/", "\\")
                    os.startfile(str2)
                    str3 = (path+'/Bagging-default-train.png').replace("/", "\\")
                    os.startfile(str3)
            else:
                QMessageBox.information(self, '提示', '第三步未运行', QMessageBox.Ok | QMessageBox.Close,
                                            QMessageBox.Close)
        else:
            QMessageBox.information(self, '提示', '第一步未运行', QMessageBox.Ok | QMessageBox.Close,
                                        QMessageBox.Close)

    def six_four_one(self):
        if self.one_state == True:
            if self.three_state == True:
                self.six_state = True
                path = self.opt.save_path + "/six/four/one"
                if os.path.exists(path):
                    shutil.rmtree(path)
                os.makedirs(path)

                dataML.AdaBoost_default(path)
                QMessageBox.information(self, '提示', '完成', QMessageBox.Ok | QMessageBox.Close,
                                        QMessageBox.Close)
                if self.opt.if_open == True:
                    str1 = (path+'/AdaBoost-default.png').replace("/", "\\")
                    os.startfile(str1)
                    str2 = (path+'/AdaBoost-default-10-fold-crossvalidation.png').replace("/", "\\")
                    os.startfile(str2)
                    str3 = (path+'/AdaBoost-default-train.png').replace("/", "\\")
                    os.startfile(str3)
            else:
                QMessageBox.information(self, '提示', '第三步未运行', QMessageBox.Ok | QMessageBox.Close,
                                            QMessageBox.Close)
        else:
            QMessageBox.information(self, '提示', '第一步未运行', QMessageBox.Ok | QMessageBox.Close,
                                        QMessageBox.Close)

    def six_five_one(self):
        if self.one_state == True:
            if self.three_state == True:
                self.six_state = True
                path = self.opt.save_path + "/six/five/one"
                if os.path.exists(path):
                    shutil.rmtree(path)
                os.makedirs(path)

                dataML.GradientBoosting_default(path)
                QMessageBox.information(self, '提示', '完成', QMessageBox.Ok | QMessageBox.Close,
                                        QMessageBox.Close)
                if self.opt.if_open == True:
                    str1 = (path+'/GradientBoosting-default.png').replace("/", "\\")
                    os.startfile(str1)
                    str2 = (path+'/GradientBoosting-default-10-fold-crossvalidation.png').replace("/", "\\")
                    os.startfile(str2)
                    str3 = (path+'/GradientBoosting-default-train.png').replace("/", "\\")
                    os.startfile(str3)
            else:
                QMessageBox.information(self, '提示', '第三步未运行', QMessageBox.Ok | QMessageBox.Close,
                                            QMessageBox.Close)
        else:
            QMessageBox.information(self, '提示', '第一步未运行', QMessageBox.Ok | QMessageBox.Close,
                                        QMessageBox.Close)

    def six_six_one(self):
        if self.one_state == True:
            if self.three_state == True:
                self.six_state = True
                path = self.opt.save_path + "/six/six/one"
                if os.path.exists(path):
                    shutil.rmtree(path)
                os.makedirs(path)

                dataML.ExtraTree_default(path)
                QMessageBox.information(self, '提示', '完成', QMessageBox.Ok | QMessageBox.Close,
                                        QMessageBox.Close)
                if self.opt.if_open == True:
                    str1 = (path+'/ExtraTree-default.png').replace("/", "\\")
                    os.startfile(str1)
                    str2 = (path+'/ExtraTree-default-10-fold-crossvalidation.png').replace("/", "\\")
                    os.startfile(str2)
                    str3 = (path+'/ExtraTree-default-train.png').replace("/", "\\")
                    os.startfile(str3)
            else:
                QMessageBox.information(self, '提示', '第三步未运行', QMessageBox.Ok | QMessageBox.Close,
                                            QMessageBox.Close)
        else:
            QMessageBox.information(self, '提示', '第一步未运行', QMessageBox.Ok | QMessageBox.Close,
                                        QMessageBox.Close)

    def six_seven_one(self):
        if self.one_state == True:
            if self.three_state == True:
                self.six_state = True
                path = self.opt.save_path + "/six/seven/one"
                if os.path.exists(path):
                    shutil.rmtree(path)
                os.makedirs(path)

                dataML.svm_default(path)
                QMessageBox.information(self, '提示', '完成', QMessageBox.Ok | QMessageBox.Close,
                                        QMessageBox.Close)
                if self.opt.if_open == True:
                    str1 = (path+'/svm-default.png').replace("/", "\\")
                    os.startfile(str1)
                    str2 = (path+'/svm-default-10-fold-crossvalidation.png').replace("/", "\\")
                    os.startfile(str2)
                    str3 = (path+'/svm-default-train.png').replace("/", "\\")
                    os.startfile(str3)
            else:
                QMessageBox.information(self, '提示', '第三步未运行', QMessageBox.Ok | QMessageBox.Close,
                                            QMessageBox.Close)
        else:
            QMessageBox.information(self, '提示', '第一步未运行', QMessageBox.Ok | QMessageBox.Close,
                                        QMessageBox.Close)

    def six_eight_one(self):
        if self.one_state == True:
            if self.three_state == True:
                self.six_state = True
                path = self.opt.save_path + "/six/eight/one"
                if os.path.exists(path):
                    shutil.rmtree(path)
                os.makedirs(path)

                dataML.DecisionTree_default(path)
                QMessageBox.information(self, '提示', '完成', QMessageBox.Ok | QMessageBox.Close,
                                        QMessageBox.Close)
                if self.opt.if_open == True:
                    str1 = (path+'/DecisionTree-default.png').replace("/", "\\")
                    os.startfile(str1)
                    str2 = (path+'/DecisionTree-default-10-fold-crossvalidation.png').replace("/", "\\")
                    os.startfile(str2)
                    str3 = (path+'/DecisionTree-default-train.png').replace("/", "\\")
                    os.startfile(str3)
            else:
                QMessageBox.information(self, '提示', '第三步未运行', QMessageBox.Ok | QMessageBox.Close,
                                            QMessageBox.Close)
        else:
            QMessageBox.information(self, '提示', '第一步未运行', QMessageBox.Ok | QMessageBox.Close,
                                        QMessageBox.Close)

    def six_nine_one(self):
        if self.one_state == True:
            if self.three_state == True:
                self.six_state = True
                path = self.opt.save_path + "/six/nine/one"
                if os.path.exists(path):
                    shutil.rmtree(path)
                os.makedirs(path)

                dataML.LinearRegression_default(path)
                QMessageBox.information(self, '提示', '完成', QMessageBox.Ok | QMessageBox.Close,
                                        QMessageBox.Close)
                if self.opt.if_open == True:
                    str1 = (path+'/LinearRegression-default.png').replace("/", "\\")
                    os.startfile(str1)
                    str2 = (path+'/LinearRegression-default-10-fold-crossvalidation.png').replace("/", "\\")
                    os.startfile(str2)
                    str3 = (path+'/LinearRegression-default-train.png').replace("/", "\\")
                    os.startfile(str3)
            else:
                QMessageBox.information(self, '提示', '第三步未运行', QMessageBox.Ok | QMessageBox.Close,
                                            QMessageBox.Close)
        else:
            QMessageBox.information(self, '提示', '第一步未运行', QMessageBox.Ok | QMessageBox.Close,
                                        QMessageBox.Close)

    def six_ten_one(self):
        if self.one_state == True:
            if self.three_state == True:
                self.six_state = True
                path = self.opt.save_path + "/six/ten/one"
                if os.path.exists(path):
                    shutil.rmtree(path)
                os.makedirs(path)

                dataML.Ridge_default(path)
                QMessageBox.information(self, '提示', '完成', QMessageBox.Ok | QMessageBox.Close,
                                        QMessageBox.Close)
                if self.opt.if_open == True:
                    str1 = (path+'/Ridge-default.png').replace("/", "\\")
                    os.startfile(str1)
                    str2 = (path+'/Ridge-default-10-fold-crossvalidation.png').replace("/", "\\")
                    os.startfile(str2)
                    str3 = (path+'/Ridge-default-train.png').replace("/", "\\")
                    os.startfile(str3)
            else:
                QMessageBox.information(self, '提示', '第三步未运行', QMessageBox.Ok | QMessageBox.Close,
                                            QMessageBox.Close)
        else:
            QMessageBox.information(self, '提示', '第一步未运行', QMessageBox.Ok | QMessageBox.Close,
                                        QMessageBox.Close)

    def six_eleven_one(self):
        if self.one_state == True:
            if self.three_state == True:
                self.six_state = True
                path = self.opt.save_path + "/six/eleven/one"
                if os.path.exists(path):
                    shutil.rmtree(path)
                os.makedirs(path)

                dataML.MLP_default(path)
                QMessageBox.information(self, '提示', '完成', QMessageBox.Ok | QMessageBox.Close,
                                        QMessageBox.Close)
                if self.opt.if_open == True:
                    str1 = (path+'/MLP-default.png').replace("/", "\\")
                    os.startfile(str1)
                    str2 = (path+'/MLP-default-10-fold-crossvalidation.png').replace("/", "\\")
                    os.startfile(str2)
                    str3 = (path+'/MLP-default-train.png').replace("/", "\\")
                    os.startfile(str3)
            else:
                QMessageBox.information(self, '提示', '第三步未运行', QMessageBox.Ok | QMessageBox.Close,
                                            QMessageBox.Close)
        else:
            QMessageBox.information(self, '提示', '第一步未运行', QMessageBox.Ok | QMessageBox.Close,
                                        QMessageBox.Close)

    def six_eleven_two(self):
        if self.dialog_state == True:
            path = self.opt.save_path + "/six/eleven/two"
            if os.path.exists(path):
                shutil.rmtree(path)
            os.makedirs(path)
            self.di.close()
            try:
                dataML.MLP_modify(float(self.num_1),float(self.num_2),int(self.num_3),int(self.num_4)
                                  ,int(self.num_5),path)
            except Exception as e:
                print(e)
            self.dialog_state = False
            QMessageBox.information(self, '提示', '完成', QMessageBox.Ok | QMessageBox.Close,
                                    QMessageBox.Close)
            if self.opt.if_open == True:
                str1 = (path+'/MLP_modify.png').replace("/", "\\")
                os.startfile(str1)
                str2 = (path+'/MLP_modify-10-fold-crossvalidation.png').replace("/", "\\")
                os.startfile(str2)
                str3 = (path+'/MLP_modify-train.png').replace("/", "\\")
                os.startfile(str3)
        else:
            QMessageBox.information(self, '提示', '未按输入', QMessageBox.Ok | QMessageBox.Close,
                                    QMessageBox.Close)
    def show_dialog_six_eleven_two(self):
        def give(a,b,c,d,e):
            self.num_1=a
            self.num_2 = b
            self.num_3 = c
            self.num_4 = d
            self.num_5 = e
            self.dialog_state = True

        if self.one_state == True:
            if self.three_state == True:
                self.six_state = True
                self.di = QtWidgets.QDialog()
                d = dialog_six_eleven_two.Ui_Dialog()
                d.setupUi(self.di)
                self.di.show()

                d.pushButton.clicked.connect(lambda :give(d.lineEdit.text(),d.lineEdit_2.text(),d.lineEdit_3.text(),d.lineEdit_4.text()
                                                          ,d.lineEdit_5.text()))
                d.pushButton_2.clicked.connect(self.six_eleven_two)
            else:
                QMessageBox.information(self, '提示', '第三步未运行', QMessageBox.Ok | QMessageBox.Close,
                                            QMessageBox.Close)
        else:
            QMessageBox.information(self, '提示', '第一步未运行', QMessageBox.Ok | QMessageBox.Close,
                                        QMessageBox.Close)


    # 7                                          # 1 3 7
    def seven_one(self):
        if self.enter_two_state == True:
            if self.one_state == True:
                if self.three_state == True:
                    self.seven_state = True
                    path = self.opt.save_path + "/seven/one"
                    if os.path.exists(path):
                        shutil.rmtree(path)
                    os.makedirs(path)

                    dataML.xgboost_default_predict(self.opt.origin_path_2,path)
                    QMessageBox.information(self, '提示', '完成', QMessageBox.Ok | QMessageBox.Close,
                                            QMessageBox.Close)
                    if self.opt.if_open == True:
                        str1 = (path+"/New_prediction_total_xgboost_default.csv").replace("/", "\\")
                        os.startfile(str1)
                else:
                    QMessageBox.information(self, '提示', '第三步未运行', QMessageBox.Ok | QMessageBox.Close,
                                                QMessageBox.Close)
            else:
                QMessageBox.information(self, '提示', '第一步未运行', QMessageBox.Ok | QMessageBox.Close,
                                            QMessageBox.Close)
        else:
            QMessageBox.information(self, '提示', '未导入预测', QMessageBox.Ok | QMessageBox.Close,
                                    QMessageBox.Close)

    def seven_two(self):
        if self.dialog_state == True:
            path = self.opt.save_path + "/seven/two"
            if os.path.exists(path):
                shutil.rmtree(path)
            os.makedirs(path)
            self.di.close()
            dataML.xgboost_modify_predict(int(self.num_1),int(self.num_2),self.num_3,self.num_4
                                  ,self.num_5,self.num_6,self.num_7, self.opt.origin_path_2,path)
            self.dialog_state =False
            QMessageBox.information(self, '提示', '完成', QMessageBox.Ok | QMessageBox.Close,
                                    QMessageBox.Close)
            if self.opt.if_open == True:
                str1 = (path+"/New_prediction_total_xgboost_modify.csv").replace("/", "\\")
                os.startfile(str1)
        else:
            QMessageBox.information(self, '提示', '未按输入', QMessageBox.Ok | QMessageBox.Close,
                                    QMessageBox.Close)
    def show_dialog_seven_two(self):
        def give(a,b,c,d,e,f,g):
            self.num_1=a
            self.num_2 = b
            self.num_3 = c
            self.num_4 = d
            self.num_5 = e
            self.num_6 = f
            self.num_7 = g
            self.dialog_state = True

        if self.enter_two_state == True:
            if self.one_state == True:
                if self.three_state == True:
                    self.seven_state = True
                    self.di = QtWidgets.QDialog()
                    d = dialog_six_one_two.Ui_Dialog()
                    d.setupUi(self.di)
                    self.di.show()

                    d.pushButton.clicked.connect(lambda :give(d.lineEdit.text(),d.lineEdit_2.text(),d.lineEdit_3.text(),d.lineEdit_4.text()
                                                              ,d.lineEdit_5.text(),d.lineEdit_6.text(),d.lineEdit_7.text()))
                    d.pushButton_2.clicked.connect(self.seven_two)
                else:
                    QMessageBox.information(self, '提示', '第三步未运行', QMessageBox.Ok | QMessageBox.Close,
                                        QMessageBox.Close)
            else:
                QMessageBox.information(self, '提示', '第一步未运行', QMessageBox.Ok | QMessageBox.Close,
                                    QMessageBox.Close)
        else:
            QMessageBox.information(self, '提示', '未导入预测', QMessageBox.Ok | QMessageBox.Close,
                                    QMessageBox.Close)

    def seven_three(self):
        if self.enter_two_state == True:
            if self.one_state == True:
                if self.three_state == True:
                    self.seven_state = True
                    path = self.opt.save_path + "/seven/three"
                    if os.path.exists(path):
                        shutil.rmtree(path)
                    os.makedirs(path)

                    dataML.rnd_search_cv_xgboost_predict(self.opt.origin_path_2, path)
                    QMessageBox.information(self, '提示', '完成', QMessageBox.Ok | QMessageBox.Close,
                                            QMessageBox.Close)
                    if self.opt.if_open == True:
                        str1 = (path+"/New_prediction_total_rnd_search_cv_xgboost.csv").replace("/", "\\")
                        os.startfile(str1)
                else:
                    QMessageBox.information(self, '提示', '第三步未运行', QMessageBox.Ok | QMessageBox.Close,
                                            QMessageBox.Close)
            else:
                QMessageBox.information(self, '提示', '第一步未运行', QMessageBox.Ok | QMessageBox.Close,
                                        QMessageBox.Close)
        else:
            QMessageBox.information(self, '提示', '未导入预测', QMessageBox.Ok | QMessageBox.Close,
                                    QMessageBox.Close)
    # 8                                          # 单独
    def eight_one_one(self):
        if self.enter_three_state == True:
            path = self.opt.save_path + "/eight/one/one"
            if os.path.exists(path):
                shutil.rmtree(path)
            os.makedirs(path)

            dataML.smiles_csv_pydel(self.opt.origin_path_3)
            dataML.pydel_featurizer(path)

            QMessageBox.information(self, '提示', '完成', QMessageBox.Ok | QMessageBox.Close,
                                    QMessageBox.Close)
            if self.opt.if_open == True:
                str1 = (path+"/pydel_featurizer_output.csv").replace("/", "\\")
                os.startfile(str1)
        else:
            QMessageBox.information(self, '提示', '未导入有机smiles', QMessageBox.Ok | QMessageBox.Close,
                                    QMessageBox.Close)

    def eight_one_two(self):
        if self.enter_three_state == True:
            path = self.opt.save_path + "/eight/one/two"
            if os.path.exists(path):
                shutil.rmtree(path)
            os.makedirs(path)

            dataML.smiles_csv_rdkit(self.opt.origin_path_3)
            dataML.rdkit_featurizer(path)

            QMessageBox.information(self, '提示', '完成', QMessageBox.Ok | QMessageBox.Close,
                                    QMessageBox.Close)
            if self.opt.if_open == True:
                str1 = (path+"/rdkit_featurizer_output.csv").replace("/", "\\")
                os.startfile(str1)
        else:
            QMessageBox.information(self, '提示', '未导入有机smiles', QMessageBox.Ok | QMessageBox.Close,
                                    QMessageBox.Close)

    def eight_two(self):
        if self.enter_four_state == True:
            path = self.opt.save_path + "/eight/two"
            if os.path.exists(path):
                shutil.rmtree(path)
            os.makedirs(path)

            dataML.inorganic_csv(self.opt.origin_path_4)
            dataML.inorganic_featurizer(path)

            QMessageBox.information(self, '提示', '完成', QMessageBox.Ok | QMessageBox.Close,
                                    QMessageBox.Close)
            if self.opt.if_open == True:
                str1 = (path+"/inorganic_featurizer_output.csv").replace("/", "\\")
                os.startfile(str1)
        else:
            QMessageBox.information(self, '提示', '未导入无机化学式', QMessageBox.Ok | QMessageBox.Close,
                                    QMessageBox.Close)

    # 9                                                               # 1 9
    def nine_one(self):
        if self.one_state==True:
            self.nine_state=True
            path = self.opt.save_path + "/nine/one"
            if os.path.exists(path):
                shutil.rmtree(path)
            os.makedirs(path)
            value, ok = QtWidgets.QInputDialog.getDouble(self, "提示", "输入皮尔森阈值:", 0.55, -10000, 10000, 2)
            dataML.gp_default(value)
            QMessageBox.information(self, '提示', '完成', QMessageBox.Ok | QMessageBox.Close,
                                    QMessageBox.Close)
        else:
            QMessageBox.information(self, '提示', '第一步未运行', QMessageBox.Ok | QMessageBox.Close,
                                    QMessageBox.Close)

    def nine_two(self):
        if self.one_state==True:
            self.nine_state=True
            path = self.opt.save_path + "/nine/two"
            if os.path.exists(path):
                shutil.rmtree(path)
            os.makedirs(path)
            value, ok = QtWidgets.QInputDialog.getDouble(self, "提示", "输入皮尔森阈值:", 0.55, -10000, 10000, 2)
            dataML.gp_tan(value)
            QMessageBox.information(self, '提示', '完成', QMessageBox.Ok | QMessageBox.Close,
                                    QMessageBox.Close)
        else:
            QMessageBox.information(self, '提示', '第一步未运行', QMessageBox.Ok | QMessageBox.Close,
                                    QMessageBox.Close)

    def nine_three(self):
        if self.one_state==True:
            self.nine_state=True
            path = self.opt.save_path + "/nine/three"
            if os.path.exists(path):
                shutil.rmtree(path)
            os.makedirs(path)
            value, ok = QtWidgets.QInputDialog.getDouble(self, "提示", "输入皮尔森阈值:", 0.7, -10000, 10000, 2)
            dataML.tSR_default(value)
            QMessageBox.information(self, '提示', '完成', QMessageBox.Ok | QMessageBox.Close,
                                    QMessageBox.Close)
        else:
            QMessageBox.information(self, '提示', '第一步未运行', QMessageBox.Ok | QMessageBox.Close,
                                    QMessageBox.Close)


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    ui = mywindow()

    ui.show()
    sys.exit(app.exec_())